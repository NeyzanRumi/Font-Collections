﻿### FREE METAL FONT COLLECTION ###

This is a collection of rock and metal style free fonts compiled by Neyzan (NeyzanRumi).

This collection is distributed under the SIL OFL v1.1 and the GNU GPL v3, as most fonts in this collection use one of the two. Individual fonts may have their own separate licenses, contact me for details.

To the best of my knowledge these fonts are free to use for any purpose (even commercial), including but not limited to redistribution, compilation and modification.

   *** See the OFL file for the SIL Open Font Licence, version 1.1 ***
   
   *** See the COPYING file for the GNU General Public Licence, version 3 ***



-----------------------------------------------------------------------------
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
-----------------------------------------------------------------------------



### For questions and suggestions please contact neyzanrumi@protonmail.com ###


